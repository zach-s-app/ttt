import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TicTacToeGUI extends JFrame implements ActionListener {

    private JButton[] buttons = new JButton[9];
    private String currentPlayer = "X";
    private boolean gameActive = true;
    private JLabel statusLabel = new JLabel("Current Player: X");

    public TicTacToeGUI() {
        setTitle("Tic-Tac-Toe");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 350); // Adjusted height
        setLayout(new BorderLayout());

        JPanel buttonPanel = new JPanel(new GridLayout(3, 3));
        for (int i = 0; i < 9; i++) {
            buttons[i] = new JButton("");
            buttons[i].setFont(new Font("Arial", Font.PLAIN, 40));
            buttons[i].addActionListener(this);
            buttonPanel.add(buttons[i]);
        }
        add(buttonPanel, BorderLayout.CENTER);

        JPanel statusPanel = new JPanel(new FlowLayout());
        statusPanel.add(statusLabel);
        add(statusPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (!gameActive) return;

        JButton clickedButton = (JButton) e.getSource();
        if (!clickedButton.getText().equals("")) return;

        clickedButton.setText(currentPlayer);
        if (checkForWin()) {
            statusLabel.setText("Player " + currentPlayer + " wins!");
            gameActive = false;
            return;
        }
        if (isBoardFull()) {
            statusLabel.setText("It's a draw!");
            gameActive = false;
            return;
        }

        currentPlayer = (currentPlayer.equals("X")) ? "O" : "X";
        statusLabel.setText("Current Player: " + currentPlayer);
    }

    private boolean checkForWin() {
        String[] board = new String[9];
        for (int i = 0; i < 9; i++) {
            board[i] = buttons[i].getText();
        }
        int[][] winPatterns = {
                {0, 1, 2}, {3, 4, 5}, {6, 7, 8}, // Rows
                {0, 3, 6}, {1, 4, 7}, {2, 5, 8}, // Columns
                {0, 4, 8}, {2, 4, 6}          // Diagonals
        };

        for (int[] pattern : winPatterns) {
            if (board[pattern[0]].equals(board[pattern[1]]) &&
                board[pattern[1]].equals(board[pattern[2]]) &&
                !board[pattern[0]].equals("")) {
                return true;
            }
        }
        return false;
    }

    private boolean isBoardFull() {
        for (JButton button : buttons) {
            if (button.getText().equals("")) {
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(TicTacToeGUI::new);
    }
}