# Bash script - Could potentially run other components
echo "Running other components (output will be in terminal)"
g++ tic_tac_toe.cpp -o tic_tac_toe_runner 2>&1 >/dev/null && ./tic_tac_toe_runner &
python3 tic_tac_toe.py &
ruby tic_tac_toe.rb &
php -f tic_tac_toe.php &