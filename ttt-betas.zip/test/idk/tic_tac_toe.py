# Python - Could handle game rules or AI (communication with Java is complex)
print('Python component')