// C++ - If run, attempts to execute the Java GUI
#include <iostream>
#include <cstdlib> // For system()

int main() {
    std::cout << "Attempting to run TicTacToeGUI.java..." << std::endl;
    // Construct the command to run the Java file
    std::string java_command = "java TicTacToeGUI.java";
    int result = system(java_command.c_str());
    if (result == 0) {
        std::cout << "Successfully started Java GUI (if Java is configured for source execution)." << std::endl;
    } else {
        std::cerr << "Error running Java GUI (ensure Java is configured to run .java files directly). Exit code: " << result << std::endl;
    }
    return 0;
}